import 'package:flutter/material.dart';

class CadastroMecanicoTela extends StatelessWidget {
  const CadastroMecanicoTela({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro Mecânico')),
      body: const Center(
        child: Text('Tela de cadastro de mecânico'),
      ),
    );
  }
}
