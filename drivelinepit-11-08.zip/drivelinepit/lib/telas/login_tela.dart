import 'package:flutter/material.dart';
import 'tipo_cadastro.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 40),
            const Text('Sign In',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const Text('Olá! Bem vindo de volta'),
            const SizedBox(height: 24),
            TextFormField(
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            const SizedBox(height: 16),
            TextFormField(
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Senha'),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const RedefinirSenhaTela(),
                    ),
                  );
                },
                child: const Text('Esqueceu a senha?',
                    style: TextStyle(color: Colors.orange)),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                // Aqui você pode colocar a lógica de login
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              child: const Text('Login'),
            ),
            const SizedBox(height: 16),
            const Row(
              children: [
                Expanded(child: Divider()),
                Text(" Ou, logue com "),
                Expanded(child: Divider())
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: const [
                Icon(Icons.g_mobiledata, size: 40),
                Icon(Icons.facebook, size: 30),
                Icon(Icons.alternate_email, size: 30),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('Não tem uma conta ainda? '),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const TipoCadastroScreen(),
                      ),
                    );
                  },
                  child: const Text('Cadastre-se'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class RedefinirSenhaTela extends StatefulWidget {
  const RedefinirSenhaTela({super.key});

  @override
  State<RedefinirSenhaTela> createState() => _RedefinirSenhaTelaState();
}

class _RedefinirSenhaTelaState extends State<RedefinirSenhaTela> {
  final _emailController = TextEditingController();
  final _novaSenhaController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Redefinir Senha')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(labelText: 'E-mail'),
                validator: (value) =>
                    value!.isEmpty ? 'Informe o e-mail' : null,
              ),
              TextFormField(
                controller: _novaSenhaController,
                decoration: const InputDecoration(labelText: 'Nova senha'),
                obscureText: true,
                validator: (value) =>
                    value!.isEmpty ? 'Informe a nova senha' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style:
                    ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text('Senha redefinida com sucesso!')),
                    );
                    Navigator.pop(context);
                  }
                },
                child: const Text('Redefinir Senha'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

