enum TipoUsuario { Cliente, Empresario }

class Usuario {
  String nome;
  String email;
  String senha;
  String telefone;
  TipoUsuario tipo;

  Usuario({
    required this.nome,
    required this.email,
    required this.senha,
    required this.telefone,
    required this.tipo,
  });
}
