class Compromisso {
  DateTime data;
  Duration hora;
  String descricao;
  String local;

  Compromisso({
    required this.data,
    required this.hora,
    required this.descricao,
    required this.local,
  });
}
