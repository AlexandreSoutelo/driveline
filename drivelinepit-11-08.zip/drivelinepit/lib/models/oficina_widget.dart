import 'servico_widgets.dart';

class Oficina {
  String nomeOficina;
  String cnpj;
  String endereco;
  List<Servico> listaServico;

  Oficina({
    required this.nomeOficina,
    required this.cnpj,
    required this.endereco,
    required this.listaServico,
  });
}